/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gemshop.util;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Manoj Priyamantha
 */
public class DbConnection {
    
     public static Connection getConnection() {
        System.out.println("Connection started");
        Connection con = null;

        String db = "gem_shop";
        String user = "root";
        String password = "Root@123#";

//        System.out.println("#Connection Working");

        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + db, user, password);
//            con = DriverManager.getConnection(dbhost, user, password);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            System.err.println("error in connection");
            e.printStackTrace();
        }
        System.out.println("#Connection Working ❤");
        return con;
    }
    
    public static void main(String[] args) {
        new DbConnection().getConnection();
    }
    
}
