
package com.gemshop.view;

import com.gemshop.util.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Manoj Priyamantha
 */
public class Mainframe extends javax.swing.JFrame {
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

   
    public Mainframe() {
        initComponents();
        
        //run db connection in constructor
        con = DbConnection.getConnection();
        
        //center window
        this.setLocationRelativeTo(null);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Mainpanel = new javax.swing.JPanel();
        Topanel = new javax.swing.JPanel();
        SystemOption = new javax.swing.JPanel();
        minimizeBtn = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();
        CompanyDetails = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Datetime = new javax.swing.JPanel();
        timeLbl = new javax.swing.JLabel();
        dateLbl = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        MidPanel = new javax.swing.JPanel();
        Maintasks = new javax.swing.JTabbedPane();
        Shoppanel = new javax.swing.JPanel();
        shopmainpanel = new javax.swing.JPanel();
        inputpanel = new javax.swing.JPanel();
        input = new javax.swing.JPanel();
        itmLbl = new javax.swing.JLabel();
        itmList = new javax.swing.JComboBox<>();
        qtyLbl = new javax.swing.JLabel();
        qtyTxt = new javax.swing.JTextField();
        qtyLbl1 = new javax.swing.JLabel();
        weightTxt = new javax.swing.JTextField();
        addBtn = new javax.swing.JButton();
        removeBtn = new javax.swing.JButton();
        discountLbl = new javax.swing.JLabel();
        discountTxt = new javax.swing.JComboBox<>();
        itemdetailspanel = new javax.swing.JPanel();
        qtystockLbl = new javax.swing.JLabel();
        qtystockTxt = new javax.swing.JLabel();
        itmpriceTxt = new javax.swing.JLabel();
        itmpriceLbl = new javax.swing.JLabel();
        imageLbl = new javax.swing.JLabel();
        billpanel = new javax.swing.JPanel();
        billtblpanel = new javax.swing.JScrollPane();
        billTbl = new javax.swing.JTable();
        cashpanel = new javax.swing.JPanel();
        totalLbl = new java.awt.Label();
        totalTxt = new java.awt.Label();
        paidLbl = new java.awt.Label();
        returnLbl = new java.awt.Label();
        paidTxt = new java.awt.TextField();
        returnTxt = new java.awt.Label();
        payBtn = new java.awt.Button();
        Stockpanel = new javax.swing.JPanel();
        stockmainpanel = new javax.swing.JPanel();
        stocktitleLbl = new javax.swing.JLabel();
        stocksubmainpanel = new javax.swing.JPanel();
        stockinputpanel = new javax.swing.JPanel();
        updateitemlist = new javax.swing.JLabel();
        stockitemLbl = new javax.swing.JLabel();
        stockqtyLbl = new javax.swing.JLabel();
        stockitemTxt = new javax.swing.JComboBox<>();
        stockqtyTxt = new javax.swing.JTextField();
        stockupdateBtn = new javax.swing.JButton();
        stockDeleteBtn = new javax.swing.JButton();
        stockweightTxt = new javax.swing.JTextField();
        stockweightLbl = new javax.swing.JLabel();
        tblscrolpanel = new javax.swing.JScrollPane();
        stocktbl = new javax.swing.JTable();
        Utilitypanel = new javax.swing.JPanel();
        utilitytitleLbl = new javax.swing.JLabel();
        utilitysubpanel = new javax.swing.JPanel();
        itemBtn = new javax.swing.JButton();
        userBtn = new javax.swing.JButton();
        itemtypeBtn = new javax.swing.JButton();
        calculatorBtn = new javax.swing.JButton();
        backupdbBtn = new javax.swing.JButton();
        discountBtn = new javax.swing.JButton();
        Reportpanel = new javax.swing.JPanel();
        reportsubpanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        dayendBtn = new javax.swing.JButton();
        salesreportLbl = new javax.swing.JLabel();
        weekendBtn = new javax.swing.JButton();
        monthendBtn = new javax.swing.JButton();
        yearendBtn = new javax.swing.JButton();
        salesBtn = new javax.swing.JButton();
        topsellingpanel = new javax.swing.JPanel();
        topsellingitemLbl = new javax.swing.JLabel();
        topitem1 = new javax.swing.JPanel();
        topitem2 = new javax.swing.JPanel();
        topitem3 = new javax.swing.JPanel();
        reporttitleLbl = new javax.swing.JLabel();
        bottom = new javax.swing.JPanel();
        RavenSoftDesigns = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(new java.awt.Dimension(1366, 720));

        Mainpanel.setBackground(new java.awt.Color(255, 255, 255));
        Mainpanel.setPreferredSize(new java.awt.Dimension(1366, 720));

        Topanel.setBackground(new java.awt.Color(0, 51, 204));
        Topanel.setPreferredSize(new java.awt.Dimension(1366, 130));

        SystemOption.setBackground(new java.awt.Color(0, 51, 204));

        minimizeBtn.setFont(new java.awt.Font("Dialog", 1, 22)); // NOI18N
        minimizeBtn.setForeground(new java.awt.Color(255, 255, 255));
        minimizeBtn.setText("-");
        minimizeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeBtnMouseClicked(evt);
            }
        });

        closeBtn.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 0, 0));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout SystemOptionLayout = new javax.swing.GroupLayout(SystemOption);
        SystemOption.setLayout(SystemOptionLayout);
        SystemOptionLayout.setHorizontalGroup(
            SystemOptionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SystemOptionLayout.createSequentialGroup()
                .addComponent(minimizeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(closeBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE))
        );
        SystemOptionLayout.setVerticalGroup(
            SystemOptionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SystemOptionLayout.createSequentialGroup()
                .addGroup(SystemOptionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(minimizeBtn)
                    .addComponent(closeBtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        CompanyDetails.setBackground(new java.awt.Color(0, 51, 204));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DAHAM SRI GEMS");

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("No 12, New Shopping Complex, Galnewa.");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("072 -6554598   025-2051682");

        javax.swing.GroupLayout CompanyDetailsLayout = new javax.swing.GroupLayout(CompanyDetails);
        CompanyDetails.setLayout(CompanyDetailsLayout);
        CompanyDetailsLayout.setHorizontalGroup(
            CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CompanyDetailsLayout.createSequentialGroup()
                .addGroup(CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(0, 148, Short.MAX_VALUE))
        );
        CompanyDetailsLayout.setVerticalGroup(
            CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CompanyDetailsLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Datetime.setBackground(new java.awt.Color(0, 51, 204));

        timeLbl.setForeground(new java.awt.Color(255, 255, 0));
        timeLbl.setText("12:00 PM");

        dateLbl.setForeground(new java.awt.Color(255, 255, 0));
        dateLbl.setText("06/12/2020");

        javax.swing.GroupLayout DatetimeLayout = new javax.swing.GroupLayout(Datetime);
        Datetime.setLayout(DatetimeLayout);
        DatetimeLayout.setHorizontalGroup(
            DatetimeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DatetimeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(timeLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(dateLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        DatetimeLayout.setVerticalGroup(
            DatetimeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DatetimeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(DatetimeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeLbl)
                    .addComponent(dateLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setText("Manoj");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 109, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout TopanelLayout = new javax.swing.GroupLayout(Topanel);
        Topanel.setLayout(TopanelLayout);
        TopanelLayout.setHorizontalGroup(
            TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(CompanyDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SystemOption, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Datetime, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        TopanelLayout.setVerticalGroup(
            TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TopanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(CompanyDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(TopanelLayout.createSequentialGroup()
                        .addComponent(SystemOption, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Datetime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        Maintasks.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 51, 204), null));

        Shoppanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51), 2));

        shopmainpanel.setPreferredSize(new java.awt.Dimension(1305, 405));

        inputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        inputpanel.setPreferredSize(new java.awt.Dimension(655, 100));

        itmLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        itmLbl.setText("ITEM NAME :");

        itmList.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        qtyLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        qtyLbl.setText("QUANTITY   :");

        qtyLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        qtyLbl1.setText("WEIGHT       :");

        addBtn.setBackground(new java.awt.Color(0, 153, 0));
        addBtn.setForeground(new java.awt.Color(255, 255, 255));
        addBtn.setText("ADD TO BILL");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        removeBtn.setBackground(new java.awt.Color(204, 0, 0));
        removeBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeBtn.setText("REMOVE FROM BILL");

        discountLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        discountLbl.setText("DISCOUNT");

        discountTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout inputLayout = new javax.swing.GroupLayout(input);
        input.setLayout(inputLayout);
        inputLayout.setHorizontalGroup(
            inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputLayout.createSequentialGroup()
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inputLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                        .addComponent(removeBtn))
                    .addGroup(inputLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(qtyLbl1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(qtyLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(itmLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(discountLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(discountTxt, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(qtyTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                            .addComponent(itmList, 0, 230, Short.MAX_VALUE)
                            .addComponent(weightTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE))))
                .addContainerGap())
        );
        inputLayout.setVerticalGroup(
            inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputLayout.createSequentialGroup()
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itmList, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itmLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(qtyLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(qtyTxt))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(qtyLbl1, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(weightTxt))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(discountTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(discountLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(addBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(removeBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        qtystockLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        qtystockLbl.setText("AVAILABLE :");

        qtystockTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        qtystockTxt.setForeground(new java.awt.Color(0, 102, 0));
        qtystockTxt.setText("10");

        itmpriceTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        itmpriceTxt.setForeground(new java.awt.Color(0, 102, 0));
        itmpriceTxt.setText("100.00");

        itmpriceLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        itmpriceLbl.setText("ITEM PRICE :");

        imageLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gemshop/images/Icons/Gem.png"))); // NOI18N

        javax.swing.GroupLayout itemdetailspanelLayout = new javax.swing.GroupLayout(itemdetailspanel);
        itemdetailspanel.setLayout(itemdetailspanelLayout);
        itemdetailspanelLayout.setHorizontalGroup(
            itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(itemdetailspanelLayout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(itemdetailspanelLayout.createSequentialGroup()
                        .addComponent(itmpriceLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(itmpriceTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(itemdetailspanelLayout.createSequentialGroup()
                        .addComponent(qtystockLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(qtystockTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(itemdetailspanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(imageLbl)))
                .addContainerGap())
        );
        itemdetailspanelLayout.setVerticalGroup(
            itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(itemdetailspanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itmpriceLbl)
                    .addComponent(itmpriceTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(qtystockLbl)
                    .addComponent(qtystockTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(imageLbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout inputpanelLayout = new javax.swing.GroupLayout(inputpanel);
        inputpanel.setLayout(inputpanelLayout);
        inputpanelLayout.setHorizontalGroup(
            inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(input, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(itemdetailspanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        inputpanelLayout.setVerticalGroup(
            inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(itemdetailspanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(input, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        billpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        billTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Item name", "item price", "qty", "weight", "discount", "sub-total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        billTbl.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        billTbl.getTableHeader().setReorderingAllowed(false);
        billtblpanel.setViewportView(billTbl);
        if (billTbl.getColumnModel().getColumnCount() > 0) {
            billTbl.getColumnModel().getColumn(1).setResizable(false);
            billTbl.getColumnModel().getColumn(2).setResizable(false);
            billTbl.getColumnModel().getColumn(3).setResizable(false);
            billTbl.getColumnModel().getColumn(4).setResizable(false);
            billTbl.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout billpanelLayout = new javax.swing.GroupLayout(billpanel);
        billpanel.setLayout(billpanelLayout);
        billpanelLayout.setHorizontalGroup(
            billpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(billtblpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
                .addContainerGap())
        );
        billpanelLayout.setVerticalGroup(
            billpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(billtblpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
                .addContainerGap())
        );

        cashpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        cashpanel.setPreferredSize(new java.awt.Dimension(1281, 141));

        totalLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        totalLbl.setText("Total Amount :");

        totalTxt.setAlignment(java.awt.Label.CENTER);
        totalTxt.setBackground(new java.awt.Color(255, 255, 255));
        totalTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        totalTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        totalTxt.setForeground(new java.awt.Color(0, 153, 0));
        totalTxt.setText("0000.00");

        paidLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        paidLbl.setText("Collected Amount :");

        returnLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        returnLbl.setText("Return Amount      :");

        paidTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        paidTxt.setForeground(new java.awt.Color(51, 51, 255));
        paidTxt.setText("0");
        paidTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paidTxtActionPerformed(evt);
            }
        });

        returnTxt.setBackground(new java.awt.Color(255, 255, 255));
        returnTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        returnTxt.setForeground(new java.awt.Color(0, 153, 0));
        returnTxt.setText("0000.00");

        payBtn.setBackground(new java.awt.Color(0, 51, 255));
        payBtn.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        payBtn.setForeground(new java.awt.Color(255, 255, 255));
        payBtn.setLabel("PAY");
        payBtn.setName(""); // NOI18N
        payBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cashpanelLayout = new javax.swing.GroupLayout(cashpanel);
        cashpanel.setLayout(cashpanelLayout);
        cashpanelLayout.setHorizontalGroup(
            cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cashpanelLayout.createSequentialGroup()
                .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cashpanelLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(payBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cashpanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(totalLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(totalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(282, 282, 282)
                        .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cashpanelLayout.createSequentialGroup()
                                .addComponent(returnLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(returnTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE))
                            .addGroup(cashpanelLayout.createSequentialGroup()
                                .addComponent(paidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(paidTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        cashpanelLayout.setVerticalGroup(
            cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cashpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cashpanelLayout.createSequentialGroup()
                        .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(paidLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(paidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(returnTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(returnLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(totalLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(totalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(payBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(136, 136, 136))
        );

        javax.swing.GroupLayout shopmainpanelLayout = new javax.swing.GroupLayout(shopmainpanel);
        shopmainpanel.setLayout(shopmainpanelLayout);
        shopmainpanelLayout.setHorizontalGroup(
            shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(shopmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cashpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(shopmainpanelLayout.createSequentialGroup()
                        .addComponent(inputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(billpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        shopmainpanelLayout.setVerticalGroup(
            shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(shopmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(billpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 305, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cashpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ShoppanelLayout = new javax.swing.GroupLayout(Shoppanel);
        Shoppanel.setLayout(ShoppanelLayout);
        ShoppanelLayout.setHorizontalGroup(
            ShoppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ShoppanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shopmainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        ShoppanelLayout.setVerticalGroup(
            ShoppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ShoppanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shopmainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Maintasks.addTab("GEM SHOP                             ", Shoppanel);

        Stockpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0), 2));

        stockmainpanel.setPreferredSize(new java.awt.Dimension(1305, 405));

        stocktitleLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stocktitleLbl.setText("STOCK MANAGEMENT");

        stocksubmainpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        stockinputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        updateitemlist.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateitemlist.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        updateitemlist.setText("UPDATE ITEM STOCK");

        stockitemLbl.setFont(new java.awt.Font("Gadugi", 1, 13)); // NOI18N
        stockitemLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        stockitemLbl.setText("ITEM NAME");

        stockqtyLbl.setFont(new java.awt.Font("Gadugi", 1, 13)); // NOI18N
        stockqtyLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        stockqtyLbl.setText("QUANTITY");

        stockitemTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "< Select Item >" }));
        stockitemTxt.setSelectedIndex(-1);
        stockitemTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockitemTxtActionPerformed(evt);
            }
        });

        stockupdateBtn.setBackground(new java.awt.Color(0, 153, 0));
        stockupdateBtn.setForeground(new java.awt.Color(255, 255, 255));
        stockupdateBtn.setText("UPDATE");
        stockupdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockupdateBtnActionPerformed(evt);
            }
        });

        stockDeleteBtn.setBackground(new java.awt.Color(204, 0, 0));
        stockDeleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        stockDeleteBtn.setText("DELETE");
        stockDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockDeleteBtnActionPerformed(evt);
            }
        });

        stockweightLbl.setFont(new java.awt.Font("Gadugi", 1, 13)); // NOI18N
        stockweightLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        stockweightLbl.setText("WEIGHT");

        javax.swing.GroupLayout stockinputpanelLayout = new javax.swing.GroupLayout(stockinputpanel);
        stockinputpanel.setLayout(stockinputpanelLayout);
        stockinputpanelLayout.setHorizontalGroup(
            stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockinputpanelLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(updateitemlist, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(stockinputpanelLayout.createSequentialGroup()
                            .addComponent(stockitemLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(stockitemTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, stockinputpanelLayout.createSequentialGroup()
                            .addComponent(stockqtyLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(stockDeleteBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(stockupdateBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(stockqtyTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(stockinputpanelLayout.createSequentialGroup()
                        .addComponent(stockweightLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(stockweightTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(154, Short.MAX_VALUE))
        );
        stockinputpanelLayout.setVerticalGroup(
            stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockinputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(updateitemlist, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stockitemTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stockitemLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stockqtyTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stockqtyLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stockweightTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stockweightLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(stockupdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(stockDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        stocktbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "ITEM NAME", "ITEM CODE", "QTY", "WEIGHT", "LAST UPDATE", "STATE"
            }
        ));
        tblscrolpanel.setViewportView(stocktbl);

        javax.swing.GroupLayout stocksubmainpanelLayout = new javax.swing.GroupLayout(stocksubmainpanel);
        stocksubmainpanel.setLayout(stocksubmainpanelLayout);
        stocksubmainpanelLayout.setHorizontalGroup(
            stocksubmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stocksubmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(stockinputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tblscrolpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 627, Short.MAX_VALUE)
                .addContainerGap())
        );
        stocksubmainpanelLayout.setVerticalGroup(
            stocksubmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stocksubmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(stocksubmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(stockinputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tblscrolpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout stockmainpanelLayout = new javax.swing.GroupLayout(stockmainpanel);
        stockmainpanel.setLayout(stockmainpanelLayout);
        stockmainpanelLayout.setHorizontalGroup(
            stockmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockmainpanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(stockmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(stocktitleLbl)
                    .addComponent(stocksubmainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        stockmainpanelLayout.setVerticalGroup(
            stockmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockmainpanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(stocktitleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(stocksubmainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout StockpanelLayout = new javax.swing.GroupLayout(Stockpanel);
        Stockpanel.setLayout(StockpanelLayout);
        StockpanelLayout.setHorizontalGroup(
            StockpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StockpanelLayout.createSequentialGroup()
                .addComponent(stockmainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 31, Short.MAX_VALUE))
        );
        StockpanelLayout.setVerticalGroup(
            StockpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(stockmainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 482, Short.MAX_VALUE)
        );

        Maintasks.addTab("STOCKS                                 ", Stockpanel);

        Utilitypanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 0), 2));

        utilitytitleLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        utilitytitleLbl.setText("UTILITIES");

        utilitysubpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        itemBtn.setText("ITEM");
        itemBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBtnActionPerformed(evt);
            }
        });

        userBtn.setText("USERS");
        userBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userBtnMouseClicked(evt);
            }
        });
        userBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userBtnActionPerformed(evt);
            }
        });

        itemtypeBtn.setText("ITEM TYPES");
        itemtypeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemtypeBtnMouseClicked(evt);
            }
        });
        itemtypeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtypeBtnActionPerformed(evt);
            }
        });

        calculatorBtn.setText("CALCULATOR");
        calculatorBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                calculatorBtnMouseClicked(evt);
            }
        });

        backupdbBtn.setText("BACKUP");
        backupdbBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backupdbBtnMouseClicked(evt);
            }
        });
        backupdbBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backupdbBtnActionPerformed(evt);
            }
        });

        discountBtn.setText("DISCOUNT");
        discountBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                discountBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout utilitysubpanelLayout = new javax.swing.GroupLayout(utilitysubpanel);
        utilitysubpanel.setLayout(utilitysubpanelLayout);
        utilitysubpanelLayout.setHorizontalGroup(
            utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(utilitysubpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(itemBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(81, 81, 81)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backupdbBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemtypeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(102, 102, 102)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(calculatorBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(discountBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(513, Short.MAX_VALUE))
        );
        utilitysubpanelLayout.setVerticalGroup(
            utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(utilitysubpanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itemBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemtypeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(discountBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(userBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backupdbBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(calculatorBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(204, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout UtilitypanelLayout = new javax.swing.GroupLayout(Utilitypanel);
        Utilitypanel.setLayout(UtilitypanelLayout);
        UtilitypanelLayout.setHorizontalGroup(
            UtilitypanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UtilitypanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(UtilitypanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(utilitysubpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(utilitytitleLbl))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        UtilitypanelLayout.setVerticalGroup(
            UtilitypanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UtilitypanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(utilitytitleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(utilitysubpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Maintasks.addTab("UTILITIES                                 ", Utilitypanel);

        Reportpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204), 2));

        reportsubpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        dayendBtn.setText("DAY END REPORT");

        salesreportLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        salesreportLbl.setText("SALES REPORTS");

        weekendBtn.setText("WEEK END REPORT");
        weekendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weekendBtnActionPerformed(evt);
            }
        });

        monthendBtn.setText("MONTH END REPORT");
        monthendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthendBtnActionPerformed(evt);
            }
        });

        yearendBtn.setText("YEAR END REPORT");
        yearendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearendBtnActionPerformed(evt);
            }
        });

        salesBtn.setText("SALES");
        salesBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salesBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salesreportLbl)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(monthendBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dayendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yearendBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(salesBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(46, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(36, 36, 36)
                    .addComponent(weekendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(45, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(salesreportLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dayendBtn)
                .addGap(38, 38, 38)
                .addComponent(monthendBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yearendBtn)
                .addGap(30, 30, 30)
                .addComponent(salesBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(105, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(93, 93, 93)
                    .addComponent(weekendBtn)
                    .addContainerGap(256, Short.MAX_VALUE)))
        );

        topsellingpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        topsellingitemLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        topsellingitemLbl.setText("TOP SELLING ITEMS");

        topitem1.setBorder(new javax.swing.border.MatteBorder(null));

        javax.swing.GroupLayout topitem1Layout = new javax.swing.GroupLayout(topitem1);
        topitem1.setLayout(topitem1Layout);
        topitem1Layout.setHorizontalGroup(
            topitem1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        topitem1Layout.setVerticalGroup(
            topitem1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 259, Short.MAX_VALUE)
        );

        topitem2.setBorder(new javax.swing.border.MatteBorder(null));
        topitem2.setPreferredSize(new java.awt.Dimension(290, 261));

        javax.swing.GroupLayout topitem2Layout = new javax.swing.GroupLayout(topitem2);
        topitem2.setLayout(topitem2Layout);
        topitem2Layout.setHorizontalGroup(
            topitem2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 288, Short.MAX_VALUE)
        );
        topitem2Layout.setVerticalGroup(
            topitem2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        topitem3.setBorder(new javax.swing.border.MatteBorder(null));

        javax.swing.GroupLayout topitem3Layout = new javax.swing.GroupLayout(topitem3);
        topitem3.setLayout(topitem3Layout);
        topitem3Layout.setHorizontalGroup(
            topitem3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 295, Short.MAX_VALUE)
        );
        topitem3Layout.setVerticalGroup(
            topitem3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 259, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout topsellingpanelLayout = new javax.swing.GroupLayout(topsellingpanel);
        topsellingpanel.setLayout(topsellingpanelLayout);
        topsellingpanelLayout.setHorizontalGroup(
            topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topsellingpanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(topsellingpanelLayout.createSequentialGroup()
                        .addComponent(topsellingitemLbl)
                        .addContainerGap(798, Short.MAX_VALUE))
                    .addGroup(topsellingpanelLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(topitem1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(topitem2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(topitem3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))))
        );
        topsellingpanelLayout.setVerticalGroup(
            topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topsellingpanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(topsellingitemLbl)
                .addGap(35, 35, 35)
                .addGroup(topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(topitem3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(topitem1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(topitem2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout reportsubpanelLayout = new javax.swing.GroupLayout(reportsubpanel);
        reportsubpanel.setLayout(reportsubpanelLayout);
        reportsubpanelLayout.setHorizontalGroup(
            reportsubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportsubpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(topsellingpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        reportsubpanelLayout.setVerticalGroup(
            reportsubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportsubpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(reportsubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(topsellingpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        reporttitleLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        reporttitleLbl.setText("REPORTS");

        javax.swing.GroupLayout ReportpanelLayout = new javax.swing.GroupLayout(Reportpanel);
        Reportpanel.setLayout(ReportpanelLayout);
        ReportpanelLayout.setHorizontalGroup(
            ReportpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportpanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(ReportpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ReportpanelLayout.createSequentialGroup()
                        .addComponent(reporttitleLbl)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(reportsubpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        ReportpanelLayout.setVerticalGroup(
            ReportpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportpanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(reporttitleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reportsubpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Maintasks.addTab("REPORTS                                ", Reportpanel);

        javax.swing.GroupLayout MidPanelLayout = new javax.swing.GroupLayout(MidPanel);
        MidPanel.setLayout(MidPanelLayout);
        MidPanelLayout.setHorizontalGroup(
            MidPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Maintasks)
        );
        MidPanelLayout.setVerticalGroup(
            MidPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MidPanelLayout.createSequentialGroup()
                .addComponent(Maintasks, javax.swing.GroupLayout.PREFERRED_SIZE, 518, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        bottom.setBackground(new java.awt.Color(0, 51, 204));
        bottom.setPreferredSize(new java.awt.Dimension(1366, 40));

        RavenSoftDesigns.setForeground(new java.awt.Color(255, 255, 255));
        RavenSoftDesigns.setText("© RavenSoftDesigns - 0716300774");

        javax.swing.GroupLayout bottomLayout = new javax.swing.GroupLayout(bottom);
        bottom.setLayout(bottomLayout);
        bottomLayout.setHorizontalGroup(
            bottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bottomLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RavenSoftDesigns, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(499, 499, 499))
        );
        bottomLayout.setVerticalGroup(
            bottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bottomLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RavenSoftDesigns)
                .addContainerGap())
        );

        javax.swing.GroupLayout MainpanelLayout = new javax.swing.GroupLayout(Mainpanel);
        Mainpanel.setLayout(MainpanelLayout);
        MainpanelLayout.setHorizontalGroup(
            MainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MidPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(bottom, javax.swing.GroupLayout.DEFAULT_SIZE, 1373, Short.MAX_VALUE)
            .addComponent(Topanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1373, Short.MAX_VALUE)
        );
        MainpanelLayout.setVerticalGroup(
            MainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainpanelLayout.createSequentialGroup()
                .addComponent(Topanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(MidPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(bottom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1373, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(Mainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        System.exit(0);
    }//GEN-LAST:event_closeBtnMouseClicked

    private void minimizeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeBtnMouseClicked
        // minimize btn:
        this.setState(Mainframe.ICONIFIED);
        
    }//GEN-LAST:event_minimizeBtnMouseClicked

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        // TODO add your handling code here:
        if (qtyTxt.getText().equals("") || weightTxt.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "enter Qty and weight ");
            
        } else{
            String data[] = {
                itmList.getSelectedItem().toString(),
                qtyTxt.getText(),
                weightTxt.getText(),
                String.valueOf(Double.parseDouble(itmpriceTxt.getText()) * Double.parseDouble(qtyTxt.getText()))
            };
            DefaultTableModel dtmObj = (DefaultTableModel) billTbl.getModel();
            dtmObj.addRow(data);
            
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void paidTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paidTxtActionPerformed
        returnTxt.setText(String.valueOf(Double.parseDouble(paidTxt.getText()) - Double.parseDouble(totalTxt.getText())));
    }//GEN-LAST:event_paidTxtActionPerformed

    private void payBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payBtnActionPerformed


    }//GEN-LAST:event_payBtnActionPerformed

    private void stockitemTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockitemTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stockitemTxtActionPerformed

    private void stockupdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockupdateBtnActionPerformed

        

    }//GEN-LAST:event_stockupdateBtnActionPerformed

    private void stockDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockDeleteBtnActionPerformed

    }//GEN-LAST:event_stockDeleteBtnActionPerformed

    private void weekendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weekendBtnActionPerformed

    }//GEN-LAST:event_weekendBtnActionPerformed

    private void monthendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthendBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_monthendBtnActionPerformed

    private void yearendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearendBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_yearendBtnActionPerformed

    private void salesBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salesBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salesBtnActionPerformed

    private void itemBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBtnActionPerformed
        // Itemsbtn
        Items items = new Items();
        items.setVisible(true);
    }//GEN-LAST:event_itemBtnActionPerformed

    private void itemtypeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemtypeBtnMouseClicked
        // Titemtypes:
        Itemtypes itemtypes = new Itemtypes();
        itemtypes.setVisible(true);
    }//GEN-LAST:event_itemtypeBtnMouseClicked

    private void itemtypeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtypeBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemtypeBtnActionPerformed

    private void discountBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_discountBtnActionPerformed
        // TODO add your handling code here:
        Discounts discounts = new Discounts();
        discounts.setVisible(true);
    }//GEN-LAST:event_discountBtnActionPerformed

    private void userBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userBtnActionPerformed

    }//GEN-LAST:event_userBtnActionPerformed

    private void userBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userBtnMouseClicked
        // TODO add your handling code here:
        Users users = new Users();
        users.setVisible(true);
    }//GEN-LAST:event_userBtnMouseClicked

    private void calculatorBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_calculatorBtnMouseClicked
        // TODO add your handling code here:
        Calculator calculator = new Calculator();
        calculator.setVisible(true);
    }//GEN-LAST:event_calculatorBtnMouseClicked

    private void backupdbBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backupdbBtnMouseClicked
        // TODO add your handling code here:
        Backups backups = new Backups();
        backups.setVisible(true);
    }//GEN-LAST:event_backupdbBtnMouseClicked

    private void backupdbBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backupdbBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_backupdbBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mainframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CompanyDetails;
    private javax.swing.JPanel Datetime;
    private javax.swing.JPanel Mainpanel;
    private javax.swing.JTabbedPane Maintasks;
    private javax.swing.JPanel MidPanel;
    private javax.swing.JLabel RavenSoftDesigns;
    private javax.swing.JPanel Reportpanel;
    private javax.swing.JPanel Shoppanel;
    private javax.swing.JPanel Stockpanel;
    private javax.swing.JPanel SystemOption;
    private javax.swing.JPanel Topanel;
    private javax.swing.JPanel Utilitypanel;
    private javax.swing.JButton addBtn;
    private javax.swing.JButton backupdbBtn;
    private javax.swing.JTable billTbl;
    private javax.swing.JPanel billpanel;
    private javax.swing.JScrollPane billtblpanel;
    private javax.swing.JPanel bottom;
    private javax.swing.JButton calculatorBtn;
    private javax.swing.JPanel cashpanel;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JLabel dateLbl;
    private javax.swing.JButton dayendBtn;
    private javax.swing.JButton discountBtn;
    private javax.swing.JLabel discountLbl;
    private javax.swing.JComboBox<String> discountTxt;
    private javax.swing.JLabel imageLbl;
    private javax.swing.JPanel input;
    private javax.swing.JPanel inputpanel;
    private javax.swing.JButton itemBtn;
    private javax.swing.JPanel itemdetailspanel;
    private javax.swing.JButton itemtypeBtn;
    private javax.swing.JLabel itmLbl;
    private javax.swing.JComboBox<String> itmList;
    private javax.swing.JLabel itmpriceLbl;
    private javax.swing.JLabel itmpriceTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel minimizeBtn;
    private javax.swing.JButton monthendBtn;
    private java.awt.Label paidLbl;
    private java.awt.TextField paidTxt;
    private java.awt.Button payBtn;
    private javax.swing.JLabel qtyLbl;
    private javax.swing.JLabel qtyLbl1;
    private javax.swing.JTextField qtyTxt;
    private javax.swing.JLabel qtystockLbl;
    private javax.swing.JLabel qtystockTxt;
    private javax.swing.JButton removeBtn;
    private javax.swing.JPanel reportsubpanel;
    private javax.swing.JLabel reporttitleLbl;
    private java.awt.Label returnLbl;
    private java.awt.Label returnTxt;
    private javax.swing.JButton salesBtn;
    private javax.swing.JLabel salesreportLbl;
    private javax.swing.JPanel shopmainpanel;
    private javax.swing.JButton stockDeleteBtn;
    private javax.swing.JPanel stockinputpanel;
    private javax.swing.JLabel stockitemLbl;
    private javax.swing.JComboBox<String> stockitemTxt;
    private javax.swing.JPanel stockmainpanel;
    private javax.swing.JLabel stockqtyLbl;
    private javax.swing.JTextField stockqtyTxt;
    private javax.swing.JPanel stocksubmainpanel;
    private javax.swing.JTable stocktbl;
    private javax.swing.JLabel stocktitleLbl;
    private javax.swing.JButton stockupdateBtn;
    private javax.swing.JLabel stockweightLbl;
    private javax.swing.JTextField stockweightTxt;
    private javax.swing.JScrollPane tblscrolpanel;
    private javax.swing.JLabel timeLbl;
    private javax.swing.JPanel topitem1;
    private javax.swing.JPanel topitem2;
    private javax.swing.JPanel topitem3;
    private javax.swing.JLabel topsellingitemLbl;
    private javax.swing.JPanel topsellingpanel;
    private java.awt.Label totalLbl;
    private java.awt.Label totalTxt;
    private javax.swing.JLabel updateitemlist;
    private javax.swing.JButton userBtn;
    private javax.swing.JPanel utilitysubpanel;
    private javax.swing.JLabel utilitytitleLbl;
    private javax.swing.JButton weekendBtn;
    private javax.swing.JTextField weightTxt;
    private javax.swing.JButton yearendBtn;
    // End of variables declaration//GEN-END:variables
}
