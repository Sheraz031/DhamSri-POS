/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gemshop.view;

import com.gemshop.util.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Manoj Priyamantha
 */
public class Itemtypes extends javax.swing.JFrame {
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    /**
     * Creates new form Items
     */
    public Itemtypes() {
        initComponents();
        this.setLocationRelativeTo(null);
         con = DbConnection.getConnection();
         loadItemTypesToTable();
    }

    public void loadItemTypesToTable(){
        
        try {
            String loaddata ="SELECT itemtype_id AS Number,itemtype_name AS ItemType_Name,updated_date AS Updated,created_date AS Created_date from itemtypes ";
            pst = con.prepareStatement(loaddata);
            rs = pst.executeQuery();
            itemtypessTbl.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
    }
    
    //load table data to fields by select
     public void tableDataToFields(){
        int r = itemtypessTbl.getSelectedRow();
        String itemtypeid = itemtypessTbl.getValueAt(r, 0).toString();
        String itemtypename = itemtypessTbl.getValueAt(r, 1).toString();
      
        itemtypeIdLbl.setText(itemtypeid);
        itemtypenameTxt.setText(itemtypename);
        
       
    }
    
    public void Clear(){
        itemtypeIdLbl.setText("");
        itemtypenameTxt.setText("");
    }
    
    public void updateItemTypes(){
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
         
         String itemtypeid = itemtypeIdLbl.getText();
         String itemtypename = itemtypenameTxt.getText();
         
         try {
             
             String updatequery = "UPDATE itemtypes SET itemtype_name='"+itemtypename+"',updated_date='"+timestamp+"' WHERE itemtype_id='"+itemtypeid+"'";
             pst = con.prepareStatement(updatequery);
             pst.execute();
            JOptionPane.showMessageDialog(null, "Item Type Updated !");
         } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
         }
         
    } 
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainpanel = new javax.swing.JPanel();
        leftpanel = new javax.swing.JPanel();
        iteminputpanel = new javax.swing.JPanel();
        itemtypeIdLbl = new javax.swing.JLabel();
        itemtypenameTxt = new javax.swing.JTextField();
        searchLbl2 = new javax.swing.JLabel();
        btnpanel = new javax.swing.JPanel();
        createBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        clearBtn = new javax.swing.JButton();
        rightpanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemtypessTbl = new javax.swing.JTable();
        itmsLbl = new javax.swing.JLabel();
        mainLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainpanel.setBackground(new java.awt.Color(102, 102, 255));

        leftpanel.setBackground(new java.awt.Color(102, 102, 255));
        leftpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        iteminputpanel.setBackground(new java.awt.Color(153, 153, 255));
        iteminputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        iteminputpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        itemtypeIdLbl.setBackground(new java.awt.Color(153, 153, 255));
        itemtypeIdLbl.setForeground(new java.awt.Color(153, 153, 255));
        itemtypeIdLbl.setText("Item Type Name");
        iteminputpanel.add(itemtypeIdLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, 25));
        iteminputpanel.add(itemtypenameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 316, 35));

        searchLbl2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl2.setForeground(new java.awt.Color(255, 255, 255));
        searchLbl2.setText("Item Type Name");
        iteminputpanel.add(searchLbl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 25));

        btnpanel.setBackground(new java.awt.Color(153, 153, 255));
        btnpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        createBtn.setBackground(new java.awt.Color(153, 255, 153));
        createBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn.setText("Create");
        createBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(204, 204, 255));
        updateBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(255, 102, 102));
        deleteBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        clearBtn.setBackground(new java.awt.Color(255, 255, 153));
        clearBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        clearBtn.setText("Clear");
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout btnpanelLayout = new javax.swing.GroupLayout(btnpanel);
        btnpanel.setLayout(btnpanelLayout);
        btnpanelLayout.setHorizontalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        btnpanelLayout.setVerticalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout leftpanelLayout = new javax.swing.GroupLayout(leftpanel);
        leftpanel.setLayout(leftpanelLayout);
        leftpanelLayout.setHorizontalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(iteminputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 580, Short.MAX_VALUE)
                    .addComponent(btnpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        leftpanelLayout.setVerticalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(iteminputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        rightpanel.setBackground(new java.awt.Color(102, 102, 255));
        rightpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jScrollPane1.setBackground(new java.awt.Color(153, 153, 255));

        itemtypessTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "item type name"
            }
        ));
        itemtypessTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemtypessTblMouseClicked(evt);
            }
        });
        itemtypessTbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                itemtypessTblKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                itemtypessTblKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(itemtypessTbl);

        itmsLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        itmsLbl.setForeground(new java.awt.Color(255, 255, 255));
        itmsLbl.setText("Item Types");

        javax.swing.GroupLayout rightpanelLayout = new javax.swing.GroupLayout(rightpanel);
        rightpanel.setLayout(rightpanelLayout);
        rightpanelLayout.setHorizontalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addComponent(itmsLbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        rightpanelLayout.setVerticalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        mainLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        mainLbl.setForeground(new java.awt.Color(255, 255, 255));
        mainLbl.setText("Item Type Management");

        closeBtn.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 0, 0));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout mainpanelLayout = new javax.swing.GroupLayout(mainpanel);
        mainpanel.setLayout(mainpanelLayout);
        mainpanelLayout.setHorizontalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(leftpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rightpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(332, 332, 332)
                .addComponent(closeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        mainpanelLayout.setVerticalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainpanelLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(closeBtn))
                .addGap(18, 18, 18)
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(leftpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rightpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        this.dispose();
        
        
          
    }//GEN-LAST:event_closeBtnMouseClicked

    private void createBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtnActionPerformed
        // create types:
        
        String itemtypename;
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        
        itemtypename = itemtypenameTxt.getText();
        
        try {
            String insertQuery = "INSERT INTO itemtypes(itemtype_name,created_date) VALUES('"+itemtypename+"','"+timestamp+"')";
            pst = con.prepareStatement(insertQuery);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane, "Item Succesfully Added !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        loadItemTypesToTable();
        Clear();
    }//GEN-LAST:event_createBtnActionPerformed

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        // TODO add your handling code here:
        Clear();
    }//GEN-LAST:event_clearBtnActionPerformed

    private void itemtypessTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemtypessTblMouseClicked
        // TODO add your handling code here:
        tableDataToFields();
    }//GEN-LAST:event_itemtypessTblMouseClicked

    private void itemtypessTblKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtypessTblKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemtypessTblKeyPressed

    private void itemtypessTblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtypessTblKeyReleased
        // TODO add your handling code here:
        tableDataToFields();
    }//GEN-LAST:event_itemtypessTblKeyReleased

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
        updateItemTypes();
        loadItemTypesToTable();
        Clear();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // TODO add your handling code here:
        int check = JOptionPane.showConfirmDialog(null, "Do you want to Delete ? ");
        
        if (check==0) {
            
            String itemid = itemtypeIdLbl.getText();
            
            try {
                String deletequery = "DELETE FROM itemtypes WHERE itemtype_id='"+itemid+"'";
                pst = con.prepareStatement(deletequery);
                pst.execute();
                JOptionPane.showMessageDialog(null, "ItemType Deleted !");
            } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            }
            
            
        }
        loadItemTypesToTable();
        Clear();
    }//GEN-LAST:event_deleteBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Itemtypes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Itemtypes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Itemtypes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Itemtypes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Itemtypes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel btnpanel;
    private javax.swing.JButton clearBtn;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JButton createBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JPanel iteminputpanel;
    private javax.swing.JLabel itemtypeIdLbl;
    private javax.swing.JTextField itemtypenameTxt;
    private javax.swing.JTable itemtypessTbl;
    private javax.swing.JLabel itmsLbl;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftpanel;
    private javax.swing.JLabel mainLbl;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JPanel rightpanel;
    private javax.swing.JLabel searchLbl2;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
