/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gemshop.view;

import com.gemshop.util.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Manoj Priyamantha
 */
public class Items extends javax.swing.JFrame {
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

   
    public Items() {
        initComponents();
        this.setLocationRelativeTo(null);
        con = DbConnection.getConnection();
        loadItemToTable();
    }

    // saved item loading to the table
    public void loadItemToTable(){
        
        try {
//             String loaddata = "select stu_id as ID,stu_name as Name,stu_age as Age,stu_grade as Grade from student";
            String loaddata ="SELECT item_id AS Number,item_name AS Item_Name,item_type AS Item_Type,price AS Price,updated_date AS Updated,created_date AS Created_Date from items ";
            pst = con.prepareStatement(loaddata);
            rs = pst.executeQuery();
            itemsTbl.setModel(DbUtils.resultSetToTableModel(rs));
                        
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e);
        }
        
        
    }
    
    //load table data to fields by select
    public void tableDataToFields(){
        int r = itemsTbl.getSelectedRow();
        String itemid = itemsTbl.getValueAt(r, 0).toString();
        String itemname = itemsTbl.getValueAt(r, 1).toString();
        String itemtype = itemsTbl.getValueAt(r, 2).toString();
        String itemprice =itemsTbl.getValueAt(r, 3).toString();
        
        itemidLbl.setText(itemid);
        itemnameTxt.setText(itemname);
        itemtypeTxt.setSelectedItem(itemtype);
        itempriceTxt.setText(itemprice);
        
    }
    
    //update items
    public void updateItems(){
        
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String itemid = itemidLbl.getText();
        String itemname = itemnameTxt.getText();
        String itemtype = itemtypeTxt.getSelectedItem().toString();
        String itemprice = itempriceTxt.getText();
        
        try {
            String updatequery = "UPDATE items SET item_name='"+itemname+"',item_type='"+itemtype+"',item_name='"+itemprice+"',updated_date='"+timestamp+"' WHERE item_id='"+itemid+"'";
            pst = con.prepareStatement(updatequery);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Item Details Updated !");
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
        
    }

       public void clearfields(){
           itemidLbl.setText("");
           itemnameTxt.setText("");
           itemtypeTxt.setSelectedIndex(0);
           itempriceTxt.setText("");
       }
       
       public void search() {
           String srch = searchTxt.getText();
           
           try {
             String searchquery = "SELECT * FROM items WHERE item_id LIKE'%"+srch+"%' OR item_name LIKE'"+srch+"'";
             pst = con.prepareStatement(searchquery);
             rs = pst.executeQuery();
             itemsTbl.setModel(DbUtils.resultSetToTableModel(rs));
               
           } catch (Exception e) {
           JOptionPane.showMessageDialog(null, e);
           }
       }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainpanel = new javax.swing.JPanel();
        leftpanel = new javax.swing.JPanel();
        serchpanel = new javax.swing.JPanel();
        searchLbl = new javax.swing.JLabel();
        searchTxt = new javax.swing.JTextField();
        iteminputpanel = new javax.swing.JPanel();
        searchLbl1 = new javax.swing.JLabel();
        searchLbl2 = new javax.swing.JLabel();
        searchLbl3 = new javax.swing.JLabel();
        searchLbl4 = new javax.swing.JLabel();
        imgPanel = new javax.swing.JPanel();
        imgLbl = new javax.swing.JLabel();
        itemnameTxt = new javax.swing.JTextField();
        itemtypeTxt = new javax.swing.JComboBox<>();
        itempriceTxt = new javax.swing.JTextField();
        imgaddresssTxt = new javax.swing.JTextField();
        imgbrowseBtn = new javax.swing.JButton();
        itemidLbl = new javax.swing.JLabel();
        btnpanel = new javax.swing.JPanel();
        createBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        clearBtn = new javax.swing.JButton();
        rightpanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemsTbl = new javax.swing.JTable();
        itmsLbl = new javax.swing.JLabel();
        mainLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainpanel.setBackground(new java.awt.Color(102, 102, 255));

        leftpanel.setBackground(new java.awt.Color(102, 102, 255));
        leftpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        serchpanel.setBackground(new java.awt.Color(153, 153, 255));
        serchpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl.setForeground(new java.awt.Color(255, 255, 255));
        searchLbl.setText("Search");

        searchTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        searchTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTxtActionPerformed(evt);
            }
        });
        searchTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTxtKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout serchpanelLayout = new javax.swing.GroupLayout(serchpanel);
        serchpanel.setLayout(serchpanelLayout);
        serchpanelLayout.setHorizontalGroup(
            serchpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(serchpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        serchpanelLayout.setVerticalGroup(
            serchpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(serchpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(serchpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        iteminputpanel.setBackground(new java.awt.Color(153, 153, 255));
        iteminputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl1.setForeground(new java.awt.Color(255, 255, 255));
        searchLbl1.setText("Item Name");

        searchLbl2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl2.setForeground(new java.awt.Color(255, 255, 255));
        searchLbl2.setText("Item Type");

        searchLbl3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl3.setForeground(new java.awt.Color(255, 255, 255));
        searchLbl3.setText("Price");

        searchLbl4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl4.setForeground(new java.awt.Color(255, 255, 255));
        searchLbl4.setText("Image");

        javax.swing.GroupLayout imgPanelLayout = new javax.swing.GroupLayout(imgPanel);
        imgPanel.setLayout(imgPanelLayout);
        imgPanelLayout.setHorizontalGroup(
            imgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(imgLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
        );
        imgPanelLayout.setVerticalGroup(
            imgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(imgLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        itemtypeTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        itemtypeTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtypeTxtActionPerformed(evt);
            }
        });

        imgbrowseBtn.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        imgbrowseBtn.setText("Browse");

        itemidLbl.setBackground(new java.awt.Color(153, 153, 255));
        itemidLbl.setForeground(new java.awt.Color(153, 153, 255));

        javax.swing.GroupLayout iteminputpanelLayout = new javax.swing.GroupLayout(iteminputpanel);
        iteminputpanel.setLayout(iteminputpanelLayout);
        iteminputpanelLayout.setHorizontalGroup(
            iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(searchLbl3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(searchLbl4, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(searchLbl1, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                        .addComponent(searchLbl2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(itemidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(iteminputpanelLayout.createSequentialGroup()
                        .addComponent(imgaddresssTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(imgbrowseBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(itemtypeTxt, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(itemnameTxt)
                    .addComponent(itempriceTxt))
                .addGap(18, 18, 18)
                .addComponent(imgPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        iteminputpanelLayout.setVerticalGroup(
            iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imgPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemnameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(itemidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itemtypeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itempriceTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(iteminputpanelLayout.createSequentialGroup()
                        .addGap(0, 5, Short.MAX_VALUE)
                        .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(imgaddresssTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(imgbrowseBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        btnpanel.setBackground(new java.awt.Color(153, 153, 255));
        btnpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        createBtn.setBackground(new java.awt.Color(153, 255, 153));
        createBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn.setText("Create");
        createBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(204, 204, 255));
        updateBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(255, 102, 102));
        deleteBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        clearBtn.setBackground(new java.awt.Color(255, 255, 153));
        clearBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        clearBtn.setText("Clear");
        clearBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout btnpanelLayout = new javax.swing.GroupLayout(btnpanel);
        btnpanel.setLayout(btnpanelLayout);
        btnpanelLayout.setHorizontalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        btnpanelLayout.setVerticalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout leftpanelLayout = new javax.swing.GroupLayout(leftpanel);
        leftpanel.setLayout(leftpanelLayout);
        leftpanelLayout.setHorizontalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(serchpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(iteminputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        leftpanelLayout.setVerticalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(serchpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(iteminputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        rightpanel.setBackground(new java.awt.Color(102, 102, 255));
        rightpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jScrollPane1.setBackground(new java.awt.Color(153, 153, 255));

        itemsTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        itemsTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemsTblMouseClicked(evt);
            }
        });
        itemsTbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                itemsTblKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(itemsTbl);

        itmsLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        itmsLbl.setForeground(new java.awt.Color(255, 255, 255));
        itmsLbl.setText("Items");

        javax.swing.GroupLayout rightpanelLayout = new javax.swing.GroupLayout(rightpanel);
        rightpanel.setLayout(rightpanelLayout);
        rightpanelLayout.setHorizontalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        rightpanelLayout.setVerticalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        mainLbl.setForeground(new java.awt.Color(255, 255, 255));
        mainLbl.setText("Items Management");

        closeBtn.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 0, 0));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout mainpanelLayout = new javax.swing.GroupLayout(mainpanel);
        mainpanel.setLayout(mainpanelLayout);
        mainpanelLayout.setHorizontalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(leftpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rightpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(327, 327, 327)
                .addComponent(closeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        mainpanelLayout.setVerticalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainpanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(closeBtn))
                .addGap(18, 18, 18)
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(leftpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rightpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        this.dispose();
    }//GEN-LAST:event_closeBtnMouseClicked

    private void searchTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchTxtActionPerformed

    private void createBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtnActionPerformed
        // item adding:
        String itemname,itemtype;
        int itemprice;
        
        //Timestamp 1
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        
        
        itemname = itemnameTxt.getText();
        itemtype = (String) itemtypeTxt.getSelectedItem();
        itemprice = Integer.parseInt(itempriceTxt.getText());
        
        try {
            
            String insertQuery ="INSERT INTO items (item_name,item_type,price,created_date) VALUES('"+itemname+"','"+itemtype+"','"+itemprice+"','"+timestamp+"')";
            pst = con.prepareStatement(insertQuery);
            pst.execute();
            
            JOptionPane.showMessageDialog(rootPane, "Item Succesfully Added !");
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
        loadItemToTable();
    }//GEN-LAST:event_createBtnActionPerformed

    private void itemtypeTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtypeTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemtypeTxtActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
        updateItems();
        loadItemToTable();
        clearfields();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void itemsTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemsTblMouseClicked
        // tableDataToFields():
        tableDataToFields();
    }//GEN-LAST:event_itemsTblMouseClicked

    private void itemsTblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemsTblKeyReleased
        // tableDataToFields():
        tableDataToFields();
    }//GEN-LAST:event_itemsTblKeyReleased

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // delete item:
        
        int check = JOptionPane.showConfirmDialog(null, "Do you want to Delete ? ");
        if (check==0) {
            String itemid = itemidLbl.getText();
            
            try {
                String deletequery = "DELETE FROM items WHERE item_id='"+itemid+"'";
                pst = con.prepareStatement(deletequery);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Item Deleted !");
            } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            }
            
            loadItemToTable();
            clearfields();
            
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void searchTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTxtKeyReleased
        // searchitems 
        search() ;
    }//GEN-LAST:event_searchTxtKeyReleased

    private void clearBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearBtnMouseClicked
        // TODO add your handling code here:
        
         clearfields();
    }//GEN-LAST:event_clearBtnMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Items().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel btnpanel;
    private javax.swing.JButton clearBtn;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JButton createBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel imgLbl;
    private javax.swing.JPanel imgPanel;
    private javax.swing.JTextField imgaddresssTxt;
    private javax.swing.JButton imgbrowseBtn;
    private javax.swing.JLabel itemidLbl;
    private javax.swing.JPanel iteminputpanel;
    private javax.swing.JTextField itemnameTxt;
    private javax.swing.JTextField itempriceTxt;
    private javax.swing.JTable itemsTbl;
    private javax.swing.JComboBox<String> itemtypeTxt;
    private javax.swing.JLabel itmsLbl;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftpanel;
    private javax.swing.JLabel mainLbl;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JPanel rightpanel;
    private javax.swing.JLabel searchLbl;
    private javax.swing.JLabel searchLbl1;
    private javax.swing.JLabel searchLbl2;
    private javax.swing.JLabel searchLbl3;
    private javax.swing.JLabel searchLbl4;
    private javax.swing.JTextField searchTxt;
    private javax.swing.JPanel serchpanel;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
